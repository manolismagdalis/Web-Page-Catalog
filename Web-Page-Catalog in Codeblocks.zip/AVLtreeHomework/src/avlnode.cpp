#include "avlnode.h"

avlnode * RootOfAvl;  //defining of the root of the AVL
